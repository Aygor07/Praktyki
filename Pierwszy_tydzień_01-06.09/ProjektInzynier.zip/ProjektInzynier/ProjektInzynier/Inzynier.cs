﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Inzynier
{
    public string Imie;
    public string Nazwisko;
    public Skutecznosc Skutecznosc;
    public int LiczbaProjektow;

    public static int WszystkieProjektyFirmy = 0;

    public static int LiczbaInzynierow = 0;

    public static int RekordProjektow = 0;

    public Inzynier(string imie, string nazwisko, Skutecznosc skutecznosc, int liczbaProjektow)
    {
        Imie = imie;
        Nazwisko = nazwisko;
        Skutecznosc = skutecznosc;

        if (liczbaProjektow < 0)
        {
            LiczbaProjektow = 0;
        }
        else
        {
            LiczbaProjektow = liczbaProjektow;
        }

        LiczbaInzynierow++;
    }


    public static string Odmiana(int liczba)
    {
        int liczbaBezwzgledna = Math.Abs(liczba);
        int ostatniaCyfra = liczbaBezwzgledna % 10;
        int ostatnieDwieCyfry = liczbaBezwzgledna % 100;

        if (liczbaBezwzgledna == 1)
        {
            return "projekt";
        }

        if (ostatniaCyfra >= 2 && ostatniaCyfra <= 4 && (ostatnieDwieCyfry < 12 || ostatnieDwieCyfry > 14))
        {
            return "projekty";
        }

        return "projektów";
    }


    public void Buduj()
    {
        int przyrost = (int)Skutecznosc;

        Console.WriteLine(Imie + " " + Nazwisko + " buduje projekt (przed budową miał: " + LiczbaProjektow + " " + Odmiana(LiczbaProjektow) + ").");

        LiczbaProjektow = LiczbaProjektow + przyrost;
        WszystkieProjektyFirmy = WszystkieProjektyFirmy + przyrost;

        Console.WriteLine("Aktualna liczba projektów to: " + LiczbaProjektow + ".");

        if (LiczbaProjektow > RekordProjektow)
        {
            RekordProjektow = LiczbaProjektow;
            Console.WriteLine("Brawo! Nowy rekord firmy! " + Imie + " " + Nazwisko + " ma teraz " + LiczbaProjektow + " " + Odmiana(LiczbaProjektow) + ".");
        }

        Awansuj();
    }


    public void Pokaz()
    {
        Console.WriteLine(Imie + " " + Nazwisko + " | zrealizowane projekty: " + LiczbaProjektow + " | poziom: " + Skutecznosc);
    }


    public static void PokazGlobalneProjekty()
    {
        string tekst = "Sumaryczna liczba projektów całej firmy: " + WszystkieProjektyFirmy;
        Console.WriteLine(tekst);
    }


    public void Awansuj()
    {
        if (Skutecznosc == Skutecznosc.SLABY && LiczbaProjektow >= 10)
        {
            Skutecznosc = Skutecznosc.DOBRY;
            Console.WriteLine("Gratulacje! " + Imie + " " + Nazwisko + " awansował ze SŁABEGO na DOBREGO!");
        }
        else if (Skutecznosc == Skutecznosc.DOBRY && LiczbaProjektow > 20)
        {
            Skutecznosc = Skutecznosc.WYBITNY;
            Console.WriteLine("Gratulacje! " + Imie + " " + Nazwisko + " awansował z DOBREGO na WYBITNEGO!");
        }
    }


    public static double SredniaProjektowNaInzyniera()
    {
        if (LiczbaInzynierow == 0)
        {
            return 0;
        }

        return (double)WszystkieProjektyFirmy / LiczbaInzynierow;
    }


    public void PorownajZ(Inzynier innyInzynier)
    {
        if (LiczbaProjektow > innyInzynier.LiczbaProjektow)
        {
            int roznica = LiczbaProjektow - innyInzynier.LiczbaProjektow;
            Console.WriteLine(Imie + " " + Nazwisko + " zrealizował więcej projektów niż " + innyInzynier.Imie + " " + innyInzynier.Nazwisko + " (o " + roznica + " " + Odmiana(roznica) + ").");
        }
        else if (LiczbaProjektow < innyInzynier.LiczbaProjektow)
        {
            int roznica = innyInzynier.LiczbaProjektow - LiczbaProjektow;
            Console.WriteLine(innyInzynier.Imie + " " + innyInzynier.Nazwisko + " zrealizował więcej projektów niż " + Imie + " " + Nazwisko + " (o " + roznica + " " + Odmiana(roznica) + ").");
        }
        else
        {
            Console.WriteLine(Imie + " " + Nazwisko + " i " + innyInzynier.Imie + " " + innyInzynier.Nazwisko + " mają dokładnie tyle samo zrealizowanych " + Odmiana(LiczbaProjektow) + ".");
        }
    }
}