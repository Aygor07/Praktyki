﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public enum Skutecznosc
{
    SLABY = 1,
    DOBRY = 2,
    WYBITNY = 3
}