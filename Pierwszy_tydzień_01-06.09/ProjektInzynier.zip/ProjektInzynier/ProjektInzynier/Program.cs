﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Zadanie 1: Podstawowa klasa Inzynier z polem statycznym");
        Console.WriteLine();

        Inzynier julian = new Inzynier("Julian", "Krówka", Skutecznosc.DOBRY, 0);
        julian.Buduj();
        julian.Pokaz();
        Inzynier.PokazGlobalneProjekty();

        Console.WriteLine();
        Console.WriteLine();


        Console.WriteLine("Zadanie 2: Symulacja pracy zespołu w funkcji main");
        Console.WriteLine();

        Inzynier[] zespol = new Inzynier[3];
        zespol[0] = new Inzynier("Kamil", "Burak", Skutecznosc.SLABY, 0);
        zespol[1] = new Inzynier("Wiktor", "Nawrocki", Skutecznosc.DOBRY, 0);
        zespol[2] = new Inzynier("Michał", "Wierzbicki", Skutecznosc.WYBITNY, 0);

        foreach (Inzynier inzynier in zespol)
        {
            for (int i = 0; i < 3; i++)
            {
                inzynier.Buduj();
            }
            Console.WriteLine();
        }

        Console.WriteLine();
        Console.WriteLine("Stan zespołu po budowie:");
        foreach (Inzynier inzynier in zespol)
        {
            inzynier.Pokaz();
        }

        Inzynier.PokazGlobalneProjekty();
        Console.WriteLine("(wliczając w to Jana z zadania 1, który ma 2 projekty)(pole statyczne działa poprawnie)");

        Console.WriteLine();
        Console.WriteLine();


        Console.WriteLine("Zadanie 3: Walidacja danych i automatyczny awans");
        Console.WriteLine();

        Inzynier tomek = new Inzynier("Tomasz", "Stawski", Skutecznosc.SLABY, -3);
        Console.WriteLine("Tomasz miał podaną ujemną liczbę projektów początkowych (-3).");
        Console.WriteLine("Po walidacji w konstruktorze ustawiono: " + tomek.LiczbaProjektow + " " + Inzynier.Odmiana(tomek.LiczbaProjektow));
        Console.WriteLine();

        for (int i = 0; i < 10; i++)
        {
            tomek.Buduj();
        }
        tomek.Pokaz();

        Console.WriteLine();
        Console.WriteLine();


        Console.WriteLine("Zadanie 4: Licznik zatrudnionych inżynierow (drugie pole statyczne)");
        Console.WriteLine();

        string wszyscyInzynierowie = julian.Imie + " " + julian.Nazwisko + ", " +
            zespol[0].Imie + " " + zespol[0].Nazwisko + ", " +
            zespol[1].Imie + " " + zespol[1].Nazwisko + ", " +
            zespol[2].Imie + " " + zespol[2].Nazwisko + ", " +
            tomek.Imie + " " + tomek.Nazwisko;

        Console.WriteLine("Liczba wszystkich utworzonych inżynierów (pole statyczne): " + Inzynier.LiczbaInzynierow + " (" + wszyscyInzynierowie + ")");
        Console.WriteLine("Średnia liczba projektów na jednego inżyniera: " + Inzynier.SredniaProjektowNaInzyniera());

        Console.WriteLine();
        Console.WriteLine();


        Console.WriteLine("Zadanie 5: Rywalizacja i premia za wydajność");
        Console.WriteLine();

        zespol[0].PorownajZ(zespol[2]);
        tomek.PorownajZ(zespol[1]);
        julian.PorownajZ(tomek);

        Console.WriteLine();
        Console.WriteLine("Aktualny rekord " + Inzynier.Odmiana(Inzynier.RekordProjektow) + " pojedynczego inżyniera (pole statyczne): " + Inzynier.RekordProjektow);

        Console.WriteLine();
    }
}