package com.example.licznik_punktow

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    var punktyA = 0
    var punktyB = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val druzynaA = findViewById<TextView>(R.id.druzynaA)
        val druzynaB = findViewById<TextView>(R.id.druzynaB)
        val wynikMeczu = findViewById<TextView>(R.id.wynikMeczu)

        val a1 = findViewById<Button>(R.id.a1)
        val a2 = findViewById<Button>(R.id.a2)
        val a3 = findViewById<Button>(R.id.a3)

        val b1 = findViewById<Button>(R.id.b1)
        val b2 = findViewById<Button>(R.id.b2)
        val b3 = findViewById<Button>(R.id.b3)

        val reset = findViewById<Button>(R.id.reset)

        a1.setOnClickListener {
            punktyA += 1
            druzynaA.text = "LA Lakers: $punktyA"
            wynikMeczu.text = "$punktyA : $punktyB"
        }

        a2.setOnClickListener {
            punktyA += 2
            druzynaA.text = "LA Lakers: $punktyA"
            wynikMeczu.text = "$punktyA : $punktyB"
        }

        a3.setOnClickListener {
            punktyA += 3
            druzynaA.text = "LA Lakers: $punktyA"
            wynikMeczu.text = "$punktyA : $punktyB"
        }

        b1.setOnClickListener {
            punktyB += 1
            druzynaB.text = "Miami Heat: $punktyB"
            wynikMeczu.text = "$punktyA : $punktyB"
        }

        b2.setOnClickListener {
            punktyB += 2
            druzynaB.text = "Miami Heat: $punktyB"
            wynikMeczu.text = "$punktyA : $punktyB"
        }

        b3.setOnClickListener {
            punktyB += 3
            druzynaB.text = "Miami Heat: $punktyB"
            wynikMeczu.text = "$punktyA : $punktyB"
        }

        reset.setOnClickListener {
            punktyA = 0
            punktyB = 0

            druzynaA.text = "LA Lakers: 0"
            druzynaB.text = "Miami Heat: 0"
            wynikMeczu.text = "0 : 0"
        }
    }
}