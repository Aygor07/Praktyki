package com.example.generator_hasla

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val dlugosc = findViewById<EditText>(R.id.dlugosc)
        val generuj = findViewById<Button>(R.id.generuj)
        val haslo = findViewById<TextView>(R.id.haslo)

        generuj.setOnClickListener {

            val tekst = dlugosc.text.toString()

            if (tekst.isEmpty()) {
                Toast.makeText(this, "Wpisz długość hasła!", Toast.LENGTH_SHORT).show()
            } else {
                val liczba = tekst.toInt()

                if (liczba <= 0) {
                    Toast.makeText(this, "Długość musi być większa od zera!", Toast.LENGTH_SHORT).show()
                } else {
                    val znaki = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()"

                    var noweHaslo = ""

                    for (i in 1..liczba) {
                        val losowaLiczba = Random.nextInt(znaki.length)
                        noweHaslo += znaki[losowaLiczba]
                    }

                    haslo.text = noweHaslo
                }
            }
        }
    }
}