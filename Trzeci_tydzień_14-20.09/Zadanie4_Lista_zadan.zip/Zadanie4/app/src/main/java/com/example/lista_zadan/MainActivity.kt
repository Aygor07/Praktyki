package com.example.lista_zadan

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    var zadania = ArrayList<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val zadanie = findViewById<EditText>(R.id.zadanie)
        val dodaj = findViewById<Button>(R.id.dodaj)
        val usun = findViewById<Button>(R.id.usun)
        val lista = findViewById<ListView>(R.id.lista)

        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_list_item_multiple_choice,
            zadania
        )

        lista.adapter = adapter

        lista.choiceMode = ListView.CHOICE_MODE_MULTIPLE

        dodaj.setOnClickListener {
            val noweZadanie = zadanie.text.toString()

            if (noweZadanie.isNotEmpty()) {
                zadania.add(noweZadanie)
                adapter.notifyDataSetChanged()

                zadanie.text.clear()
            }
        }

        usun.setOnClickListener {
            for (i in zadania.size - 1 downTo 0) {

                if (lista.isItemChecked(i)) {
                    zadania.removeAt(i)
                }
            }
            adapter.notifyDataSetChanged()

            lista.clearChoices()
        }
    }
}