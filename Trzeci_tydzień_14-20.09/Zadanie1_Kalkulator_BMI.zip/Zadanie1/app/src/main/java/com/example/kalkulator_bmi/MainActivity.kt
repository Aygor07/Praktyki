package com.example.kalkulator_bmi

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val waga = findViewById<EditText>(R.id.waga)
        val wzrost = findViewById<EditText>(R.id.wzrost)
        val oblicz = findViewById<Button>(R.id.oblicz)
        val wynik = findViewById<TextView>(R.id.wynik)

        oblicz.setOnClickListener {

            val w = waga.text.toString().toDouble()
            val wz = wzrost.text.toString().toDouble() / 100

            val bmi = w / (wz * wz)

            if (bmi < 18.5) {
                wynik.text = "Twoje BMI: %.2f\nNiedowaga".format(bmi)
            } else if (bmi < 25) {
                wynik.text = "Twoje BMI: %.2f\nPrawidłowa waga".format(bmi)
            } else {
                wynik.text = "Twoje BMI: %.2f\nNadwaga".format(bmi)
            }
        }
    }
}