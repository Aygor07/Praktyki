﻿using System.Collections.ObjectModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Lista_zadan
{
    public partial class MainWindow : Window
    {
        private ObservableCollection<string> zadania = new ObservableCollection<string>();

        public MainWindow()
        {
            InitializeComponent();

            ListaZadan.ItemsSource = zadania;

            zadania.Add("Zdać praktyki");
            zadania.Add("Zrobić zadania domowe");
        }

        private void Dodaj_Click(object sender, RoutedEventArgs e)
        {
            string tekst = NoweZadanie.Text.Trim();

            if (string.IsNullOrEmpty(tekst))
            {
                MessageBox.Show("Wpisz treść zadania przed dodaniem.");
                return;
            }

            zadania.Add(tekst);

            NoweZadanie.Text = "";
        }

        private void UsunZaznaczone_Click(object sender, RoutedEventArgs e)
        {
            if (ListaZadan.SelectedItem is string zaznaczoneZadanie)
            {
                zadania.Remove(zaznaczoneZadanie);
            }
            else
            {
                MessageBox.Show("Najpierw zaznacz zadanie, które chcesz usunąć.");
            }
        }
    }
}