﻿
using System.Text;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Formularz_rejestracyjny
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Zarejestruj_Click(object sender, RoutedEventArgs e)
        {
            bool formularzPoprawny = true;

            if (string.IsNullOrWhiteSpace(PoleImie.Text))
            {
                PokazBlad(PoleImie, BladImie, "Imię jest wymagane!");
                formularzPoprawny = false;
            }
            else
            {
                UkryjBlad(PoleImie, BladImie);
            }

            if (string.IsNullOrWhiteSpace(PoleNazwisko.Text))
            {
                PokazBlad(PoleNazwisko, BladNazwisko, "Nazwisko jest wymagane!");
                formularzPoprawny = false;
            }
            else
            {
                UkryjBlad(PoleNazwisko, BladNazwisko);
            }

            string wzorzecEmail = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
            if (string.IsNullOrWhiteSpace(PoleEmail.Text) || !Regex.IsMatch(PoleEmail.Text, wzorzecEmail))
            {
                PokazBlad(PoleEmail, BladEmail, "Podaj poprawny adres e-mail!");
                formularzPoprawny = false;
            }
            else
            {
                UkryjBlad(PoleEmail, BladEmail);
            }

            if (string.IsNullOrEmpty(PoleHaslo.Password) || PoleHaslo.Password.Length < 6)
            {
                PokazBladHaslo(PoleHaslo, BladHaslo, "Hasło musi mieć co najmniej 6 znaków!");
                formularzPoprawny = false;
            }
            else
            {
                UkryjBladHaslo(PoleHaslo, BladHaslo);
            }

            if (PolePotwierdzHaslo.Password != PoleHaslo.Password || string.IsNullOrEmpty(PolePotwierdzHaslo.Password))
            {
                PokazBladHaslo(PolePotwierdzHaslo, BladPotwierdzHaslo, "Hasła nie są takie same!");
                formularzPoprawny = false;
            }
            else
            {
                UkryjBladHaslo(PolePotwierdzHaslo, BladPotwierdzHaslo);
            }

            if (PoleRegulamin.IsChecked != true)
            {
                BladRegulamin.Text = "Musisz zaakceptować regulamin!";
                formularzPoprawny = false;
            }
            else
            {
                BladRegulamin.Text = "";
            }

            if (formularzPoprawny)
            {
                MessageBox.Show("Rejestracja przebiegła pomyślnie!");
            }
        }


        private void PokazBlad(System.Windows.Controls.TextBox pole, System.Windows.Controls.TextBlock komunikat, string tresc)
        {
            pole.Tag = "Blad";
            komunikat.Text = tresc;
        }

        private void UkryjBlad(System.Windows.Controls.TextBox pole, System.Windows.Controls.TextBlock komunikat)
        {
            pole.Tag = null;
            komunikat.Text = "";
        }

        private void PokazBladHaslo(System.Windows.Controls.PasswordBox pole, System.Windows.Controls.TextBlock komunikat, string tresc)
        {
            pole.Tag = "Blad";
            komunikat.Text = tresc;
        }

        private void UkryjBladHaslo(System.Windows.Controls.PasswordBox pole, System.Windows.Controls.TextBlock komunikat)
        {
            pole.Tag = null;
            komunikat.Text = "";
        }
    }
}