﻿using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using Microsoft.Win32;

namespace Galeria_obrazow
{
    public partial class MainWindow : Window
    {
        private ObservableCollection<Zdjecie> zdjecia = new ObservableCollection<Zdjecie>();

        public MainWindow()
        {
            InitializeComponent();
            ListaZdjec.ItemsSource = zdjecia;
        }

        private void WybierzObrazy_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "Obrazy (*.jpg;*.jpeg;*.png;*.bmp)|*.jpg;*.jpeg;*.png;*.bmp|Wszystkie pliki (*.*)|*.*";
            dialog.Multiselect = true;

            if (dialog.ShowDialog() == true)
            {
                foreach (string sciezka in dialog.FileNames)
                {
                    BitmapImage miniatura = new BitmapImage();
                    miniatura.BeginInit();
                    miniatura.UriSource = new Uri(sciezka);
                    miniatura.DecodePixelWidth = 100;
                    miniatura.CacheOption = BitmapCacheOption.OnLoad;
                    miniatura.EndInit();

                    Zdjecie noweZdjecie = new Zdjecie
                    {
                        SciezkaPliku = sciezka,
                        NazwaPliku = Path.GetFileName(sciezka),
                        Miniatura = miniatura
                    };

                    zdjecia.Add(noweZdjecie);
                }
            }
        }

        private void ListaZdjec_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ListaZdjec.SelectedItem is Zdjecie wybrane)
            {
                BitmapImage pelnyObraz = new BitmapImage();
                pelnyObraz.BeginInit();
                pelnyObraz.UriSource = new Uri(wybrane.SciezkaPliku);
                pelnyObraz.CacheOption = BitmapCacheOption.OnLoad;
                pelnyObraz.EndInit();

                DuzyPodglad.Source = pelnyObraz;
            }
        }
    }
}