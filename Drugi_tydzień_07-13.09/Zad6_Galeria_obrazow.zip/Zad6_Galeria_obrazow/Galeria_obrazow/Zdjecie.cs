﻿using System.Windows.Media.Imaging;

namespace Galeria_obrazow
{
    public class Zdjecie
    {
        public string SciezkaPliku { get; set; }
        public string NazwaPliku { get; set; }
        public BitmapImage Miniatura { get; set; }
    }
}