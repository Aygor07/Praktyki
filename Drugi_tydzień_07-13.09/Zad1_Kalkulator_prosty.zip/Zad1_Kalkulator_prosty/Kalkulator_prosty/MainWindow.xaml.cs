﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Kalkulator_prosty
{
    public partial class MainWindow : Window
    {
        private double pierwszaLiczba = 0;
        private string wybranaOpcja = "";
        private bool czyszczeniePola = true;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Cyfra_Click(object sender, RoutedEventArgs e)
        {
            Button przycisk = (Button)sender;
            string cyfra = przycisk.Content.ToString();

            if (czyszczeniePola)
            {
                Wynik.Text = cyfra;
                czyszczeniePola = false;
            }
            else
            {
                if (Wynik.Text == "0")
                {
                    Wynik.Text = cyfra;
                }
                else
                {
                    Wynik.Text = Wynik.Text + cyfra;
                }
            }
        }

        private void Operator_Click(object sender, RoutedEventArgs e)
        {
            Button przycisk = (Button)sender;

            pierwszaLiczba = double.Parse(Wynik.Text);
            wybranaOpcja = przycisk.Tag.ToString();

            czyszczeniePola = true;
        }

        private void Rowna_Click(object sender, RoutedEventArgs e)
        {
            double drugaLiczba = double.Parse(Wynik.Text);
            double wynikDzialania = 0;

            if (wybranaOpcja == "+")
            {
                wynikDzialania = pierwszaLiczba + drugaLiczba;
            }
            else if (wybranaOpcja == "-")
            {
                wynikDzialania = pierwszaLiczba - drugaLiczba;
            }
            else if (wybranaOpcja == "*")
            {
                wynikDzialania = pierwszaLiczba * drugaLiczba;
            }
            else if (wybranaOpcja == "/")
            {
                if (drugaLiczba == 0)
                {
                    MessageBox.Show("Nie można dzielić przez zero!");
                    return;
                }
                wynikDzialania = pierwszaLiczba / drugaLiczba;
            }

            Wynik.Text = wynikDzialania.ToString();
            czyszczeniePola = true;
        }

        private void Czysc_Click(object sender, RoutedEventArgs e)
        {
            Wynik.Text = "0";
            pierwszaLiczba = 0;
            wybranaOpcja = "";
            czyszczeniePola = true;
        }
    }
}