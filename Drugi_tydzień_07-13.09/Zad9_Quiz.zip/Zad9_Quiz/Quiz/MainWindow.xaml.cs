﻿using System.Text;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Quiz
{
    public partial class MainWindow : Window
    {
        private List<Pytanie> pytania = new List<Pytanie>();
        private int aktualnyIndeks = 0;
        private int punkty = 0;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Rozpocznij_Click(object sender, RoutedEventArgs e)
        {
            WczytajPytania();

            aktualnyIndeks = 0;
            punkty = 0;

            PokazEkran(PanelPytanie);
            PokazPytanie();
        }

        private void WczytajPytania()
        {
            string zawartoscPliku = File.ReadAllText("pytania.json");
            pytania = JsonSerializer.Deserialize<List<Pytanie>>(zawartoscPliku);
        }

        private void PokazPytanie()
        {
            Pytanie aktualne = pytania[aktualnyIndeks];

            TekstPytania.Text = (aktualnyIndeks + 1) + ". " + aktualne.Tresc;

            KontenerOdpowiedzi.Children.Clear();

            for (int i = 0; i < aktualne.Odpowiedzi.Count; i++)
            {
                RadioButton przycisk = new RadioButton();
                przycisk.Content = aktualne.Odpowiedzi[i];
                przycisk.GroupName = "Odpowiedzi";
                przycisk.Tag = i;
                przycisk.FontSize = 14;
                przycisk.Margin = new Thickness(0, 5, 0, 5);

                KontenerOdpowiedzi.Children.Add(przycisk);
            }
        }

        private void Dalej_Click(object sender, RoutedEventArgs e)
        {
            int? wybranyIndeks = null;

            foreach (var element in KontenerOdpowiedzi.Children)
            {
                if (element is RadioButton rb && rb.IsChecked == true)
                {
                    wybranyIndeks = (int)rb.Tag;
                }
            }

            if (wybranyIndeks == null)
            {
                MessageBox.Show("Zaznacz odpowiedź aby przejść dalej!");
                return;
            }

            if (wybranyIndeks == pytania[aktualnyIndeks].IndeksPoprawnej)
            {
                punkty++;
            }

            aktualnyIndeks++;

            if (aktualnyIndeks < pytania.Count)
            {
                PokazPytanie();
            }
            else
            {
                TekstWyniku.Text = "Twój wynik: " + punkty + " / " + pytania.Count;
                PokazEkran(PanelPodsumowanie);
            }
        }

        private void PokazEkran(StackPanel ekranDoPokazania)
        {
            PanelStart.Visibility = Visibility.Collapsed;
            PanelPytanie.Visibility = Visibility.Collapsed;
            PanelPodsumowanie.Visibility = Visibility.Collapsed;

            ekranDoPokazania.Visibility = Visibility.Visible;
        }
    }
}