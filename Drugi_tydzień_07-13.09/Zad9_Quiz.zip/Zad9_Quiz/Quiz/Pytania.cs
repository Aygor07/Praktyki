﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quiz
{
    public class Pytanie
    {
        public string Tresc { get; set; }
        public List<string> Odpowiedzi { get; set; }
        public int IndeksPoprawnej { get; set; }
    }
}
