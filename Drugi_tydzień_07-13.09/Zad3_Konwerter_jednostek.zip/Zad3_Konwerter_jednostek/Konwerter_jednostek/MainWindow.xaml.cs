﻿using System.Globalization;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Konwerter_jednostek
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void WyborJednostki_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Przelicz();
        }

        private void WartoscWejsciowa_TextChanged(object sender, TextChangedEventArgs e)
        {
            Przelicz();
        }

        private void Przelicz()
        {
            if (WyborJednostki == null || WartoscWejsciowa == null || WynikPrzeliczenia == null)
            {
                return;
            }

            double wartosc;
            bool czyPoprawnaLiczba = double.TryParse(
                WartoscWejsciowa.Text,
                NumberStyles.Any,
                CultureInfo.InvariantCulture,
                out wartosc);

            if (!czyPoprawnaLiczba)
            {
                WynikPrzeliczenia.Text = "Wynik: podaj poprawną liczbę";
                return;
            }

            int wybranyIndeks = WyborJednostki.SelectedIndex;
            double wynik = 0;
            string jednostka = "";

            switch (wybranyIndeks)
            {
                case 0:
                    wynik = wartosc * 0.621371;
                    jednostka = "mil";
                    break;

                case 1:
                    wynik = wartosc / 0.621371;
                    jednostka = "km";
                    break;

                case 2:
                    wynik = wartosc * 2.20462;
                    jednostka = "lb";
                    break;

                case 3:
                    wynik = wartosc / 2.20462;
                    jednostka = "kg";
                    break;

                case 4:
                    wynik = wartosc * 9.0 / 5.0 + 32;
                    jednostka = "°F";
                    break;

                case 5:
                    wynik = (wartosc - 32) * 5.0 / 9.0;
                    jednostka = "°C";
                    break;
            }

            WynikPrzeliczenia.Text = "Wynik: " + Math.Round(wynik, 2) + " " + jednostka;
        }
    }
}