﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Baza_kontaktow
{
    public class Kontakt
    {
        public int Id { get; set; }
        public string Imie { get; set; }
        public string Telefon { get; set; }
        public string Email { get; set; }
    }
}
