﻿using System.Collections.ObjectModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Data.Sqlite;

namespace Baza_kontaktow
{
    public partial class MainWindow : Window
    {
        private readonly string polaczenie = "Data Source=kontakty.db";

        private ObservableCollection<Kontakt> kontakty = new ObservableCollection<Kontakt>();

        public MainWindow()
        {
            InitializeComponent();

            PrzygotujBazeDanych();
            WczytajKontakty();

            ListaKontaktow.ItemsSource = kontakty;
        }

        private void PrzygotujBazeDanych()
        {
            using (var polaczenieDoBazy = new SqliteConnection(polaczenie))
            {
                polaczenieDoBazy.Open();

                var polecenie = polaczenieDoBazy.CreateCommand();
                polecenie.CommandText = @"
                    CREATE TABLE IF NOT EXISTS Kontakty (
                        Id INTEGER PRIMARY KEY AUTOINCREMENT,
                        Imie TEXT,
                        Telefon TEXT,
                        Email TEXT
                    )";
                polecenie.ExecuteNonQuery();
            }
        }

        private void WczytajKontakty()
        {
            kontakty.Clear();

            using (var polaczenieDoBazy = new SqliteConnection(polaczenie))
            {
                polaczenieDoBazy.Open();

                var polecenie = polaczenieDoBazy.CreateCommand();
                polecenie.CommandText = "SELECT Id, Imie, Telefon, Email FROM Kontakty";

                using (var czytnik = polecenie.ExecuteReader())
                {
                    while (czytnik.Read())
                    {
                        kontakty.Add(new Kontakt
                        {
                            Id = czytnik.GetInt32(0),
                            Imie = czytnik.GetString(1),
                            Telefon = czytnik.IsDBNull(2) ? "" : czytnik.GetString(2),
                            Email = czytnik.IsDBNull(3) ? "" : czytnik.GetString(3)
                        });
                    }
                }
            }
        }

        private void Dodaj_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(PoleImie.Text))
            {
                MessageBox.Show("Podaj przynajmniej imię.");
                return;
            }

            using (var polaczenieDoBazy = new SqliteConnection(polaczenie))
            {
                polaczenieDoBazy.Open();

                var polecenie = polaczenieDoBazy.CreateCommand();
                polecenie.CommandText = @"
                    INSERT INTO Kontakty (Imie, Telefon, Email)
                    VALUES ($imie, $telefon, $email)";

                polecenie.Parameters.AddWithValue("$imie", PoleImie.Text);
                polecenie.Parameters.AddWithValue("$telefon", PoleTelefon.Text);
                polecenie.Parameters.AddWithValue("$email", PoleEmail.Text);

                polecenie.ExecuteNonQuery();
            }

            WczytajKontakty();
            WyczyscFormularz();
        }

        private void Zapisz_Click(object sender, RoutedEventArgs e)
        {
            if (ListaKontaktow.SelectedItem is Kontakt wybrany)
            {
                using (var polaczenieDoBazy = new SqliteConnection(polaczenie))
                {
                    polaczenieDoBazy.Open();

                    var polecenie = polaczenieDoBazy.CreateCommand();
                    polecenie.CommandText = @"
                        UPDATE Kontakty
                        SET Imie = $imie, Telefon = $telefon, Email = $email
                        WHERE Id = $id";

                    polecenie.Parameters.AddWithValue("$imie", PoleImie.Text);
                    polecenie.Parameters.AddWithValue("$telefon", PoleTelefon.Text);
                    polecenie.Parameters.AddWithValue("$email", PoleEmail.Text);
                    polecenie.Parameters.AddWithValue("$id", wybrany.Id);

                    polecenie.ExecuteNonQuery();
                }

                WczytajKontakty();
                WyczyscFormularz();
            }
            else
            {
                MessageBox.Show("Najpierw zaznacz kontakt na liście, który chcesz edytować!");
            }
        }

        private void Usun_Click(object sender, RoutedEventArgs e)
        {
            if (ListaKontaktow.SelectedItem is Kontakt wybrany)
            {
                using (var polaczenieDoBazy = new SqliteConnection(polaczenie))
                {
                    polaczenieDoBazy.Open();

                    var polecenie = polaczenieDoBazy.CreateCommand();
                    polecenie.CommandText = "DELETE FROM Kontakty WHERE Id = $id";
                    polecenie.Parameters.AddWithValue("$id", wybrany.Id);

                    polecenie.ExecuteNonQuery();
                }

                WczytajKontakty();
                WyczyscFormularz();
            }
            else
            {
                MessageBox.Show("Najpierw zaznacz kontakt na liście, który chcesz usunąć!");
            }
        }

        private void ListaKontaktow_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (ListaKontaktow.SelectedItem is Kontakt wybrany)
            {
                PoleImie.Text = wybrany.Imie;
                PoleTelefon.Text = wybrany.Telefon;
                PoleEmail.Text = wybrany.Email;
            }
        }

        private void WyczyscFormularz()
        {
            PoleImie.Text = "";
            PoleTelefon.Text = "";
            PoleEmail.Text = "";
        }
    }
}