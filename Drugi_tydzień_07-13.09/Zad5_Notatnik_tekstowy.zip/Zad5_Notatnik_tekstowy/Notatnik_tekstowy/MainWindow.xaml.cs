﻿using System.Text;
using System.Windows;
using System.IO;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Win32;

namespace Notatnik_tekstowy
{
    public partial class MainWindow : Window
    {
        private string aktualnaSciezkaPliku = "";

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Nowy_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult odpowiedz = MessageBox.Show(
                "Czy chcesz utworzyć nowy plik? Niezapisane zmiany zostaną utracone.",
                "Nowy plik",
                MessageBoxButton.YesNo);

            if (odpowiedz == MessageBoxResult.Yes)
            {
                EdytorTekstu.Text = "";
                aktualnaSciezkaPliku = "";
            }
        }

        private void Otworz_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "Pliki tekstowe (*.txt)|*.txt|Wszystkie pliki (*.*)|*.*";

            if (dialog.ShowDialog() == true)
            {
                EdytorTekstu.Text = File.ReadAllText(dialog.FileName);
                aktualnaSciezkaPliku = dialog.FileName;
            }
        }

        private void Zapisz_Click(object sender, RoutedEventArgs e)
        {
            if (aktualnaSciezkaPliku == "")
            {
                ZapiszJako_Click(sender, e);
            }
            else
            {
                File.WriteAllText(aktualnaSciezkaPliku, EdytorTekstu.Text);
            }
        }

        private void ZapiszJako_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog dialog = new SaveFileDialog();
            dialog.Filter = "Pliki tekstowe (*.txt)|*.txt|Wszystkie pliki (*.*)|*.*";

            if (dialog.ShowDialog() == true)
            {
                File.WriteAllText(dialog.FileName, EdytorTekstu.Text);
                aktualnaSciezkaPliku = dialog.FileName;
            }
        }

        private void Zamknij_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}