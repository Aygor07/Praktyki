﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Edytor_rysunkow
{
    public partial class MainWindow : Window
    {
        private bool czyRysuje = false;
        private Point punktStart;
        private Shape? aktualnyKsztalt;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void PlanszaRysunku_MouseDown(object sender, MouseButtonEventArgs e)
        {
            czyRysuje = true;
            punktStart = e.GetPosition(PlanszaRysunku);

            Brush wybranyKolor = PobierzWybranyKolor();
            double grubosc = SuwakGrubosci.Value;

            string wybranyKsztalt = (WyborKsztaltu.SelectedItem as System.Windows.Controls.ComboBoxItem).Content.ToString();

            if (wybranyKsztalt == "Linia")
            {
                Line nowaLinia = new Line();
                nowaLinia.X1 = punktStart.X;
                nowaLinia.Y1 = punktStart.Y;
                nowaLinia.X2 = punktStart.X;
                nowaLinia.Y2 = punktStart.Y;
                nowaLinia.Stroke = wybranyKolor;
                nowaLinia.StrokeThickness = grubosc;

                aktualnyKsztalt = nowaLinia;
            }
            else if (wybranyKsztalt == "Prostokąt")
            {
                Rectangle nowyProstokat = new Rectangle();
                nowyProstokat.Stroke = wybranyKolor;
                nowyProstokat.StrokeThickness = grubosc;
                Canvas.SetLeft(nowyProstokat, punktStart.X);
                Canvas.SetTop(nowyProstokat, punktStart.Y);

                aktualnyKsztalt = nowyProstokat;
            }
            else if (wybranyKsztalt == "Koło")
            {
                Ellipse noweKolo = new Ellipse();
                noweKolo.Stroke = wybranyKolor;
                noweKolo.StrokeThickness = grubosc;
                Canvas.SetLeft(noweKolo, punktStart.X);
                Canvas.SetTop(noweKolo, punktStart.Y);

                aktualnyKsztalt = noweKolo;
            }

            PlanszaRysunku.Children.Add(aktualnyKsztalt);
        }

        private void PlanszaRysunku_MouseMove(object sender, MouseEventArgs e)
        {
            if (!czyRysuje || aktualnyKsztalt == null)
            {
                return;
            }

            Point punktAktualny = e.GetPosition(PlanszaRysunku);

            if (aktualnyKsztalt is Line linia)
            {
                linia.X2 = punktAktualny.X;
                linia.Y2 = punktAktualny.Y;
            }
            else
            {
                double lewy = System.Math.Min(punktStart.X, punktAktualny.X);
                double gorny = System.Math.Min(punktStart.Y, punktAktualny.Y);
                double szerokosc = System.Math.Abs(punktAktualny.X - punktStart.X);
                double wysokosc = System.Math.Abs(punktAktualny.Y - punktStart.Y);

                Canvas.SetLeft(aktualnyKsztalt, lewy);
                Canvas.SetTop(aktualnyKsztalt, gorny);
                aktualnyKsztalt.Width = szerokosc;
                aktualnyKsztalt.Height = wysokosc;
            }
        }

        private void PlanszaRysunku_MouseUp(object sender, MouseButtonEventArgs e)
        {
            czyRysuje = false;
            aktualnyKsztalt = null;
        }

        private Brush PobierzWybranyKolor()
        {
            string nazwaKoloru = (WyborKoloru.SelectedItem as System.Windows.Controls.ComboBoxItem).Content.ToString();

            switch (nazwaKoloru)
            {
                case "Czerwony": return Brushes.Red;
                case "Niebieski": return Brushes.Blue;
                case "Zielony": return Brushes.Green;
                case "Pomarańczowy": return Brushes.Orange;
                default: return Brushes.Black;
            }
        }

        private void Wyczysc_Click(object sender, RoutedEventArgs e)
        {
            PlanszaRysunku.Children.Clear();
        }
    }
}