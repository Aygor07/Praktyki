﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Zegar
{
    public partial class MainWindow : Window
    {
        private DispatcherTimer zegarSystemowy;

        public MainWindow()
        {
            InitializeComponent();

            zegarSystemowy = new DispatcherTimer();
            zegarSystemowy.Interval = TimeSpan.FromSeconds(1);
            zegarSystemowy.Tick += ZegarSystemowy_Tick;
            zegarSystemowy.Start();

            AktualizujZegar();
        }

        private void ZegarSystemowy_Tick(object sender, EventArgs e)
        {
            AktualizujZegar();
        }

        private void AktualizujZegar()
        {
            DateTime teraz = DateTime.Now;

            double katSekund = teraz.Second * 6;
            double katMinut = teraz.Minute * 6 + teraz.Second * 0.1;
            double katGodzin = (teraz.Hour % 12) * 30 + teraz.Minute * 0.5;

            ObrotSekund.Angle = katSekund;
            ObrotMinut.Angle = katMinut;
            ObrotGodzin.Angle = katGodzin;

            WyswietlaczCyfrowy.Text = teraz.ToString("HH:mm:ss");
        }
    }
}